# wavemin
DWT only with db1-db10 filters
